@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client.model;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;