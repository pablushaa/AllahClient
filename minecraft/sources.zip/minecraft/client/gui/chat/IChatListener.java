package net.minecraft.client.gui.chat;

import net.minecraft.util.text.ChatType;
import net.minecraft.util.text.ITextComponent;

public interface IChatListener
{
    void func_192576_a(ChatType p_192576_1_, ITextComponent p_192576_2_);
}
